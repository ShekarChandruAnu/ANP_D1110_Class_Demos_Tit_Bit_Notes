package com.aun.finale;
final class MyFinalClass
{
	//BY DEFAULT THE FOLLOWING METHOD WILL final
	// means cannot be overridden
	public void finalMethod1()
	{
		System.out.println("Displaying Content in Final Method....");
	}
}
class MyClass /* extends MyFinalClass Not Allowed */
{
	int score = 76;
	final static int GRACE = 5; // constant
	public void displayNonFinalMethod1()
	{
		score+=5; // score = score + 5 allowed
		//grace = grace+5; NOT ALLOWED
		System.out.println("Displayin Contents of Non Final Method...");
		System.out.println("The Score is Incremented "+score);
		System.out.println("The Grace Marks is "+GRACE);
	}
	public final void displayFinalMethod2()
	{
		System.out.println("Displaying Contents of Final Method 2 ");
	}
	
}
class MyDerived extends MyClass
{
	@Override
	public void displayNonFinalMethod1()
	{
		System.out.println("Displayin Contents of Non Final Method.In the Overridden Method..");
	}
	/* NOT ALLOWED to override a final Method of NOn Final Class
	@Override
	public final void displayFinalMethod2()
	{
		System.out.println("Displaying Contents of Final Method 2 ");
	}*/
	
}
public class MySampleFinal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyClass mc = new MyClass();
		mc.displayNonFinalMethod1();
		mc.displayFinalMethod2();

	}

}
