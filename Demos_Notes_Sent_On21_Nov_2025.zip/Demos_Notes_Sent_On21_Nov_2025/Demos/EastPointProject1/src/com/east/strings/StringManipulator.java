package com.east.strings;

public class StringManipulator {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1 = "Hello World";
		System.out.println("The String is "+str1);
		
		str1 = "New Hello World";
		System.out.println("The New String is "+str1);
	}

}
