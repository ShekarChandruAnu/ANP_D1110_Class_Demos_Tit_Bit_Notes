package com.east.anu;

public class Sample2DArray {

	int arr[][] = new int[3][4];
	public void manipulate2DArray()
	{
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<4;j++)
			{
				arr[i][j] = (i+j)*10;
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sample2DArray s2d = new Sample2DArray();
		s2d.manipulate2DArray();

	}

}
