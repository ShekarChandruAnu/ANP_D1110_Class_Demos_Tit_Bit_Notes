package com.east.anu;

public class CommandLineArgsSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("The Cities are");
		for(int i=0;i<args.length;i++)
		{
			System.out.println(args[i]);
		}

	}

}
