package com.east.anu;

public class Customer {
	
	String customerId;
	String customerName;
	String customerAddress;
	String customerPhone;
	int purchaseValue;

	public Customer() {
		super();
	}

	public Customer(String customerId, String customerName, String customerAddress, String customerPhone,
			int purchaseValue) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.customerPhone = customerPhone;
		this.purchaseValue = purchaseValue;
	}

	public Customer(String customerId, String customerName, String customerAddress, String customerPhone) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.customerPhone = customerPhone;
	}

	public Customer(String customerId, String customerName, String customerAddress) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public int getPurchaseValue() {
		return purchaseValue;
	}

	public void setPurchaseValue(int purchaseValue) {
		this.purchaseValue = purchaseValue;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerAddress="
				+ customerAddress + ", customerPhone=" + customerPhone + ", purchaseValue=" + purchaseValue + "]";
	}/* */
	
	
	// LOMBOK enable us to generate Constructors/getters/setters/toString
	//Eclipse also can generate
	
	public static void main(String[] args)
	{
		Customer customer1 = new Customer("C001","Harsha","RTNagar","9839399393",10000);
		System.out.println("Customer Details "+customer1);
	}

}
