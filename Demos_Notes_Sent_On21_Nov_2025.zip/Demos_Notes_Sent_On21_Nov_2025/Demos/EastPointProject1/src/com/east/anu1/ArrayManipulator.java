package com.east.anu1;

public class ArrayManipulator {

	
	public Point[]  manipulateArray()
	{
		Point points[] = new Point[10];
		/*
		points[0] = new Point();
		points[1] = new Point();
		points[2] = new Point();
		OR
		points[0] = new Point(10,20);
		points[1] = new Point(12,22);
		points[2] = new Point(14,24);
		*/
		for(int i=0;i<10;i++)
		{
			points[i] = new Point(i+10,i+20);
		}
		
		return points;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayManipulator amanip = new ArrayManipulator();
		Point[] myPoints = amanip.manipulateArray();
		/*myPoints[0].displayPointCoordinates();
		myPoints[1].displayPointCoordinates();*/
		for(int i=0;i<myPoints.length;i++)
		{
			myPoints[i].displayPointCoordinates();
		}

	}

}
