package com.east.anu1;

public class Point {
	
	int xCoord;
	int yCoord;
	
	
	public Point() {
		super();
	}


	public Point(int xCoord, int yCoord) {
		super();
		this.xCoord = xCoord;
		this.yCoord = yCoord;
	}
	
	public void displayPointCoordinates()
	{
		System.out.println("The X Coordinate is "+xCoord+"  ANd the Y Coordinate is "+yCoord);
	}

}
