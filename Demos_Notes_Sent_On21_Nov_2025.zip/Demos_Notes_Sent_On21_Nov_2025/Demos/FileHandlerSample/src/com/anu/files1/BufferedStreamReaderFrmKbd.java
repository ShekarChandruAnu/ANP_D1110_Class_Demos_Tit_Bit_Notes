package com.anu.files1;

import java.io.BufferedInputStream;
import java.io.IOException;

public class BufferedStreamReaderFrmKbd {

	BufferedInputStream bis;
	byte mybytes[] = new byte[100];
	public void readFromKeyBoardThroughBuffer()
	{
		//bis = new BufferedInputStream(new FileInputStream("customer.txt"));
		//bis.read(mybytes);
		bis = new BufferedInputStream(System.in);
		System.out.println("Enter a String....");
		try {
			bis.read(mybytes);
			String str = new String(mybytes);
			System.out.println("Data Read from Keyboard "+str);
			bis.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BufferedStreamReaderFrmKbd bskbd = new BufferedStreamReaderFrmKbd();
		bskbd.readFromKeyBoardThroughBuffer();

	}

}
