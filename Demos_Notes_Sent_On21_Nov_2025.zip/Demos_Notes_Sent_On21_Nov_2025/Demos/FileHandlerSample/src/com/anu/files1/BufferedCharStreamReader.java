package com.anu.files1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class BufferedCharStreamReader {

	BufferedReader br;
	//byte mybytes[] = new byte[100];
	public void readFromCharStreamThruBuffer()
	{
		try {
			br = new BufferedReader(new FileReader("students.txt"));
			String str = br.readLine();
			br.close();
			System.out.println("The Data Read from Char Stream thru Buffer...."+str);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedCharStreamReader bcsr = new BufferedCharStreamReader();
		bcsr.readFromCharStreamThruBuffer();

	}

}
