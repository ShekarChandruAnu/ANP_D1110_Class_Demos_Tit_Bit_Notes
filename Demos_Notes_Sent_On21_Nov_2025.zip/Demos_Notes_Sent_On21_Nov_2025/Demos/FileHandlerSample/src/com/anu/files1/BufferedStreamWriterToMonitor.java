package com.anu.files1;

import java.io.BufferedOutputStream;
import java.io.IOException;

public class BufferedStreamWriterToMonitor {

	BufferedOutputStream bos;
	byte mybytes[] = new byte[100];
	String str = "We are writing Data to Monitor";
	public void writeToMonitorThroughBuffer()
	{
		//bos = new BufferedOutputStream(new FileOutputStream("customer.txt"))
		bos = new BufferedOutputStream(System.out);
		mybytes = str.getBytes();
		
		try {
			bos.write(mybytes);
			bos.flush();
			System.out.println("We wrote to Monitor...");
			bos.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedStreamWriterToMonitor bswm = new BufferedStreamWriterToMonitor();
		bswm.writeToMonitorThroughBuffer();

	}

}
