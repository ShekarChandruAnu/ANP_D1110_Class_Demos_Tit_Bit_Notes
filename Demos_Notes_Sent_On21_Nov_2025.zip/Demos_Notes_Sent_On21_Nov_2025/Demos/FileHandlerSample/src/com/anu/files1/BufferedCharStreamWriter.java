package com.anu.files1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedCharStreamWriter {

	BufferedWriter bw;
	String str = "We are writing to Char Stream through Buffer";
	public void writeToCharStreamThruBuffer()
	{
		try {
		//	bw = new BufferedWriter(new FileWriter("students.txt"),100000);
			bw = new BufferedWriter(new FileWriter("students.txt"),100000);
			bw.write(str);
			bw.flush();
			bw.close();
			System.out.println("We have written to char stream thru buffer successfully..");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BufferedCharStreamWriter bcsw = new BufferedCharStreamWriter();
		bcsw.writeToCharStreamThruBuffer();

	}

}
