package com.anu.serdes;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializationSample {

	ObjectOutputStream ops;
	public void serializeEmployee()
	{
		Employee emp1 = new Employee("E001","Harsha","RTNagar","9393939939",10000);
		try {
			ops = new ObjectOutputStream(new FileOutputStream("employees.txt"));
			ops.writeObject(emp1);
			ops.flush();
			ops.close();
			System.out.println("The Employee Object is Serialized Successfully.....");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SerializationSample serialSample = new SerializationSample();
		serialSample.serializeEmployee();

	}

}
