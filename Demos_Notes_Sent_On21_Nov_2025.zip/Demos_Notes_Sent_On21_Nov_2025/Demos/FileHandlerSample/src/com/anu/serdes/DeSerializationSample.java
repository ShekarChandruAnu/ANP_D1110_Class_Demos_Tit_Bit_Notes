package com.anu.serdes;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeSerializationSample {

	ObjectInputStream ois;
	
	public void deSerializeEmployee()
	{
		try {
			ois = new ObjectInputStream(new FileInputStream("employees.txt"));
			Employee employee =  (Employee) ois.readObject();
			System.out.println("The DeSerialized Object is "+employee);
			ois.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(ClassNotFoundException cnfe)
		{
			cnfe.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DeSerializationSample dss = new DeSerializationSample();
		dss.deSerializeEmployee();

	}

}
