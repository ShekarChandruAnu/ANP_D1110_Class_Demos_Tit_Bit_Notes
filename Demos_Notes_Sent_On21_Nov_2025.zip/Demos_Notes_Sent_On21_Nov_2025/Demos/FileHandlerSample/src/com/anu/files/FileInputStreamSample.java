package com.anu.files;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputStreamSample {

	
	FileInputStream fis;
	byte mybytes[] = new byte[100];
	public void readFromBinaryStream()
	{
		try {
			fis = new FileInputStream("customer.txt");
			fis.read(mybytes);
			String str = new String(mybytes);
			System.out.println("The Data Read from file is :"+str);
			fis.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileInputStreamSample fiss = new FileInputStreamSample();
		fiss.readFromBinaryStream();

	}

}
