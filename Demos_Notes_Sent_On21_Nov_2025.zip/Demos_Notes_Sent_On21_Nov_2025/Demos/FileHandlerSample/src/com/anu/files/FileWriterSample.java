package com.anu.files;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriterSample {
	
	FileWriter fw;
	String str = "We are writing to Char Stream file";
	public void writeToFileThruCharStream()
	{
		try {
			fw = new FileWriter("supplier.txt");
			fw.write(str);
			fw.flush();
			fw.close();
			System.out.println("Written into Char Stream successfully...");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileWriterSample fws = new FileWriterSample();
		fws.writeToFileThruCharStream();
		

	}

}
