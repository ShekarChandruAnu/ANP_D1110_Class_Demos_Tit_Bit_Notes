package com.anu.files;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderSample {

	FileReader fr;
	int myChar;
	public void readFromFileThruCharStream()
	{
		try {
			fr = new FileReader("supplier.txt");
			System.out.println("The Data Read...");
			while( (myChar=fr.read()) != -1 ) // it returns -1 when it reaches eof
			{
				System.out.print((char)myChar);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileReaderSample frs = new FileReaderSample();
		frs.readFromFileThruCharStream();
	}

}
