package com.anu.poly1;

public class ShapesMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Shapes shape = new Shapes(); CANNOT INSTANTIATE THE ABSTRACT CLASSES
		Shapes shape;
		// Pointing to the Rectangle class
		shape = new Rectangle();
		shape.draw();
		//Pointing to the Triangle Class
		shape = new Triangle();
		shape.draw();
		//Pointing to the Polygon
		shape = new Polygon();
		shape.draw();
		shape.displayAbstract();
		

	}

}
