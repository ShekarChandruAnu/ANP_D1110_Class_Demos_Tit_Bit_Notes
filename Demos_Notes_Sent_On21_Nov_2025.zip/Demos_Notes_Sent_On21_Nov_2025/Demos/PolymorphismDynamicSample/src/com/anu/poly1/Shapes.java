package com.anu.poly1;

public abstract class Shapes {
	
	public abstract void draw();//------>freedom y
	
	public void displayAbstract()
	{
		System.out.println("The Abstract Class Features displayed...");
	}

}
