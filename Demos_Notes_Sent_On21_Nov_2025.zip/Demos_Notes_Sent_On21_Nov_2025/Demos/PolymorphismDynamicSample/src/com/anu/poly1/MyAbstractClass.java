package com.anu.poly1;

public abstract class MyAbstractClass {

	//public abstract void myAbstractMethod();
	
	public void nonAbstractMethod1()
	{
		System.out.println("Non Abstract Method 1");
	}
	public void nonAbstractMethod2()
	{
		System.out.println("Non Abstract Method 2");
	}
	
}
