package com.anu.poly1;
class BaseClass
{
	public void display()
	{
		System.out.println("Displaying Base Classe Features...");
	}
}
class DerivedClass extends BaseClass
{
	//ANNOTATIONS indicator which gives information to the compiler how the following lines shoudl be treated
	
	public void display()
	{
		System.out.println("Displaying Derived Class Features...");
	}
}
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DerivedClass dc  = new DerivedClass();
		dc.display();
		// THIS IS LATE BINDING - RESOLUTION i.e The Method Address vs Object (association) takes
		//place - during the runtime
		//This is Late Binding
		BaseClass bc = new BaseClass();
		bc.display();

	}

}
