package com.anu.poly2;

public class CompanyDetails {

}
