package com.anu.poly2;

public interface Insurance {

	public void calculatePremium();
	public void openPolicy();
	public void terminatePolicy();
}
