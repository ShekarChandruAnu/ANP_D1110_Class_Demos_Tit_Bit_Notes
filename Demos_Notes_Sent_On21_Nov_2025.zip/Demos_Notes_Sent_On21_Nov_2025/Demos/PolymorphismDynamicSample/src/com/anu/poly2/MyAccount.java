package com.anu.poly2;

public class MyAccount extends Taxation implements Account,Insurance 
{

	@Override
	public void calculateOutstandingAmt() {
		// TODO Auto-generated method stub
		System.out.println("Outstanding Amount is .....");
	}

	@Override
	public void calculateRedemptionPoints() {
		// TODO Auto-generated method stub
		System.out.println("The Redemption Points calculated is ....");
	}

	@Override
	public void calculateInterest() {
		// TODO Auto-generated method stub
		System.out.println("The Interest calculated for this account is ...");
		
	}

	@Override
	public void deposit() {
		// TODO Auto-generated method stub
		System.out.println("The amount Deposited is ....");
		
	}

	@Override
	public void withdraw() {
		// TODO Auto-generated method stub
		System.out.println("The amount is withdrawn successfully....");
		
	}

	@Override
	public void viewTransactions() {
		// TODO Auto-generated method stub
		System.out.println("The Transactions for the Period are ....");
		
	}

	@Override
	public void calculatePremium() {
		// TODO Auto-generated method stub
		System.out.println("The Premium Calculated is ....");
		
	}

	@Override
	public void openPolicy() {
		// TODO Auto-generated method stub
		System.out.println("The Policy Is opened....");
		
	}

	@Override
	public void terminatePolicy() {
		// TODO Auto-generated method stub
		System.out.println("The Policy is Terminated ");
		
	}

	@Override
	public void openAccount() {
		// TODO Auto-generated method stub
		
		System.out.println("Account is Open...");
		
	}

	@Override
	public void closeAccount() {
		// TODO Auto-generated method stub
		System.out.println("The ACcount is closed...");
		
	}

}
