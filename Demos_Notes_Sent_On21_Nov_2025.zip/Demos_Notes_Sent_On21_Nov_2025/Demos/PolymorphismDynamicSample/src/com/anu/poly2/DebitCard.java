package com.anu.poly2;

public interface DebitCard {

	public void deposit();
	public void withdraw();
	public void viewTransactions();
}
