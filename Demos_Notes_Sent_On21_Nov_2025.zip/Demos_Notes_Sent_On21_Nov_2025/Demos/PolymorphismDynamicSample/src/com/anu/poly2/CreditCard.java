package com.anu.poly2;

public interface CreditCard {

	public void calculateOutstandingAmt();
	public void calculateRedemptionPoints();
	public void calculateInterest();
}
