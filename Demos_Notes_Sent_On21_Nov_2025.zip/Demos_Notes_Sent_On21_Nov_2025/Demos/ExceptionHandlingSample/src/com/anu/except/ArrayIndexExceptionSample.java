package com.anu.except;

public class ArrayIndexExceptionSample {

	public void manipulateArray()
	{
		int arr[] = new int[10];
		System.out.println("We are about to manipulate an Array...");
		try
		{
			for(int i=0;i<=10;i++)
			{
				
				arr[i] = (i+1)* 10;
				//arithmetic operation
				System.out.println("The Element is "+arr[i]);
			}
		}
	
		catch(ArrayIndexOutOfBoundsException xyz)
		{
			xyz.printStackTrace();
			//System.out.println(aie.getMessage());
			
		}
		catch(ArithmeticException ae)
		{
			ae.printStackTrace();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		
		
		System.out.println("We are exiting Array Manipulation..");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("We are in the Main method...");
		System.out.println("We are about to invoke Array Manipulation Method");
		ArrayIndexExceptionSample aie = new ArrayIndexExceptionSample();
		
		aie.manipulateArray();
		
		System.out.println("Back in the Main Exiting Main...");

	}

}
