package com.anu.except1;
//CUSTOM EXCEPTION or USER DEFINED EXCEPTION
public class InvalidAgeException extends Exception{

	String message;
	public InvalidAgeException(String message)
	{
		this.message = message;
	}
	
}
