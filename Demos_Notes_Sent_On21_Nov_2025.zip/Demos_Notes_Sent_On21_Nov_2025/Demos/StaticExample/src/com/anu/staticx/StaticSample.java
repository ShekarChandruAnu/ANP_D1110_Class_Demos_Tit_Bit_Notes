package com.anu.staticx;

public class StaticSample {

	int nonStaticVar;//0
	static int staticVar;//0
	/*
	 * static methods can access only static variables
	 * non static methods can access both static variable and non static variable
	 * static Method can be accessible with the ClassName we don't need an instance to call static method
	 */
	public static void staticMethod1()
	{
		staticVar++; 
		// nonStaticVar++; Not Allowed
		System.out.println("The value of StaticVar in StaticMethod 1   :"+staticVar);//
	}
	public void nonStaticMethod1()
	{
		staticVar++;
		nonStaticVar++;
		System.out.println("The Value of staticVar in NonSTaticMethod 1   :"+staticVar);//
		System.out.println("The Value of NonSTaticVar in NonStaticMethod 1 :"+nonStaticVar);// 1 //1
	}
	public static void staticMethod2()
	{
		staticVar++;
		System.out.println("The value of StaticVar in StaticMethod2   :"+staticVar);//
	}
	public void nonStaticMethod2()
	{
		staticVar++;
		nonStaticVar++;
		System.out.println("The Value of staticVar in NonSTaticMethod 2   :"+staticVar);//
		System.out.println("The Value of NonSTaticVar in NonStaticMethod 2 :"+nonStaticVar);// 2  //2
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticSample stat1 = new StaticSample();
		StaticSample.staticMethod1(); //staticvar : 1
		stat1.nonStaticMethod1(); //staticvar: 2  nonstaticvar: 1
		stat1.nonStaticMethod2(); //staticvar: 3  nonstaticvar : 2
		
		StaticSample stat2 = new StaticSample();
		StaticSample.staticMethod2();//staticvar 4 
		stat2.nonStaticMethod1();  //staticvar : 5   nonStaticvar: 1
		stat2.nonStaticMethod2(); //staticvar : 6	nonstaticvar: 2
		
		
		
	}

}
