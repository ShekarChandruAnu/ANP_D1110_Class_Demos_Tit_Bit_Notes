package com.anu.poly;

public class MethodOverloadingSample {

	public void calculateSalary(double basic,double hra,double cca,double allowances,String employeeName)
	{
		double grossSalary = basic + hra + cca + allowances;
		System.out.println(" The Gross Salary for "+employeeName+" is "+grossSalary);
	}
	public void calculateSalary(double basic,double hra,double cca,double allowances,double dedns,String employeeName)
	{
		double grossSalary = basic + hra + cca + allowances;
		double nettSalary = (basic + hra + cca + allowances) - dedns;
		System.out.println(" The Gross Salary for "+employeeName+" is "+grossSalary+" and Nett Salary is "+nettSalary);
	}
	public void calculateSalary(double basic,double hra,double cca,double allowances,double dedns,double bonusPcntg,String employeeName)
	{
		double grossSalary = basic + hra + cca + allowances;
		double nettSalary = (basic + hra + cca + allowances) - dedns;
		double empBonus = (bonusPcntg / 100 )*grossSalary;
		System.out.println(" The Gross Salary for "+employeeName+" is "+grossSalary+" and Nett Salary is "+nettSalary+ " And the Bonus is "+empBonus);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodOverloadingSample molsObject = new MethodOverloadingSample();
		molsObject.calculateSalary(1000, 250, 250, 350, "Harsha");
		System.out.println("----------");
		molsObject.calculateSalary(1000, 250, 250, 350, 350, "Harsha");
		System.out.println("----------");
		molsObject.calculateSalary(1000, 250, 250, 350, 350, 12, "Harsha");

	}

}
