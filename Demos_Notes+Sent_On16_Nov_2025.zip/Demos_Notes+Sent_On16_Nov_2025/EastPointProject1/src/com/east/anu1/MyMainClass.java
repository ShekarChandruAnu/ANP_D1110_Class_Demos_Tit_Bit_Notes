package com.east.anu1;

public class MyMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BookShelf bShelf1 = new BookShelf();
		bShelf1.acceptBookShelfDetails();
		bShelf1.displayBookShelfDetails();
		
		Furniture furniture = new Furniture();
		furniture.acceptFurnitureDetails();
		furniture.displayFurnitureDetails();
		

	}

}
