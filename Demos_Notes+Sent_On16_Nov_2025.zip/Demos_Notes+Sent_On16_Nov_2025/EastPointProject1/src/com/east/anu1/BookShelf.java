package com.east.anu1;

public class BookShelf extends Furniture{

	int noOfShelves;
	
	public void acceptBookShelfDetails()
	{
		/*System.out.println("Enter the Length ");
		length = scan1.nextInt();
		System.out.println("Enter the Height ");
		height = scan1.nextInt();
		System.out.println("Enter the width");
		width = scan1.nextInt();*/
		//Furniture furn = new Furniture();
		super.acceptFurnitureDetails(); 
		System.out.println("Enter the noOfShelves");
		noOfShelves = scan1.nextInt();
		
	}
	public void displayBookShelfDetails()
	{
		System.out.println("The BookShelf Details are ");
		/*System.out.println("The Length is  :"+length);
		System.out.println("The Height is :"+height);
		System.out.println("The Width is :"+width);*/
		super.displayFurnitureDetails();
		System.out.println("No of Shelves is :"+noOfShelves);
		
	}
	

}
