package com.east.anu;

public class JaggedArraySample {

	int jarr[][] = new int[4][];
	public void manipulateJaggedArray()
	{
		jarr[0] = new int[4];
		jarr[1] = new int[5];
		jarr[2] = new int[3];
		jarr[3] = new int[6];
		for(int i=0;i<4;i++)
		{
			jarr[0][i] = (i+1)*10;
			System.out.print(jarr[0][i]+" ");
		}
		System.out.println();
		for(int j=0;j<5;j++)
		{
			jarr[1][j] = (j+1)*100;
			System.out.print(jarr[1][j]+" ");
		}
		System.out.println();
		for(int k=0;k<3;k++)
		{
			jarr[2][k] = (k+1)*1000;
			System.out.print(jarr[2][k]+" ");
		}
		System.out.println();
		for(int l=0;l<5;l++)
		{
			jarr[3][l] = (l+1)*10000;
			System.out.print(jarr[3][l]+" ");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JaggedArraySample jars = new JaggedArraySample();
		jars.manipulateJaggedArray();

	}

}
