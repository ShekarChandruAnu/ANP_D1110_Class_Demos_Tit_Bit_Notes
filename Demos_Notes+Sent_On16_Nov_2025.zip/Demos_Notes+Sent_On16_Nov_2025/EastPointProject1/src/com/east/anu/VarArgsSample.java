package com.east.anu;

public class VarArgsSample {

	//BASICALL VAR ARGS is a DYNAMIC ARRAY
	 /* int arr[] = new int[5];
	public void manipulateArray()
	{
		for(int i=0;i<5;i++)
		{
			arr[i] = (i+1)*10;
			System.out.print(arr[i]+" ");
		}
		for(int i=0;i<arr.length;i++) // EVERY ARRAY WE CREATE IS AN OBJECT OF Array(Array is class
		{
			arr[i] = (i+1)*10;
			System.out.print(arr[i]+" ");
		}
		
	}*/
	public void add(int a,int b)
	{
		
		
	}
	// VAR ARGS : represents parameters in a method which can accept Variable number of arguments
	public void calculateAverage(int num1,int num2,String... cities)
	{
		double average = (num1 + num2 ) / 2;
		System.out.println("The avarage calculated for the following Cities is "+average);
		for(int i=0;i<cities.length;i++)
		{
			System.out.println(cities[i]);
		}
		
		
	}
	// Dharwad KCGupta 123 125 143 ----> 
	// Hubballi RCNag  345 456 567 786 654
	public void calculateAvgVotesPerConst(String city,String dcName,int...  votingNos)
	{
		int sumOfVotes = 0;
		double avgVotesPerConstituency =0.0;
		for(int i=0;i<votingNos.length;i++)
		{
			sumOfVotes = sumOfVotes + votingNos[i];
		}
		avgVotesPerConstituency = sumOfVotes / votingNos.length;
		System.out.println("The DC for the City "+city+" is "+dcName+" Average Votes PerConstituency in this City is "+avgVotesPerConstituency);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VarArgsSample vars = new VarArgsSample();
		
		/*vars.add(10, 20);
		vars.add(100, 200);
		vars.add(1000, 2000);
		vars.add();//IS THIS ALLOWED*/
		
		
		/*
		vars.calculateAverage(300, 400, "BLR","CHN","HYD","KOL","DEL");
		vars.calculateAverage(1300, 1400, "KOC","CHN","HYD","MUM");
		vars.calculateAverage(30, 40, "BLR","HUB","MLR");
		vars.calculateAverage(2300, 2400, "BLR","GAN");
		vars.calculateAverage(3300, 3400, "BLR","CHN","PAT","NAG","DEL","MADU");
		vars.calculateAverage(3000, 4000);// WILL THIS BE ACCEPTED - YES */
		vars.calculateAvgVotesPerConst("Mangalore", "KC Gupta", 1234,2345,4567,5432);
		vars.calculateAvgVotesPerConst("Hubballi", "RC Khattar", 4324,3245,6172,6748,8736,4253);
		vars.calculateAvgVotesPerConst("Coorg", "Suhasini", 1234,2345,4567);
		vars.calculateAvgVotesPerConst("Dharwad", "Malini", 1234,2345,4567,5432,3245,3456,5431);
		
	}

}
