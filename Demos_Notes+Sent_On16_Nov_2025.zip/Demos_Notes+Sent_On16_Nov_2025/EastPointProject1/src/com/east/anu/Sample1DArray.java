package com.east.anu;

public class Sample1DArray {
	
	int arr1[] = new int[10];
	public void manipulate1DArray()
	{
		for(int i=0;i<10;i++)
		{
			arr1[i] = (i+1)*100;
			System.out.println("Element is "+arr1[i]);
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sample1DArray s1d = new Sample1DArray();
		s1d.manipulate1DArray();

	}

}
