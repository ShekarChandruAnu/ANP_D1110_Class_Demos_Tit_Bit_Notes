package com.east.anu;

public class EmployeeDetail
{
	String empName;
	String empAddress;
	String empPhone;
	String empMail;
	int empSalary;
	//Parameterless Constructor
	/**/	
	public EmployeeDetail()
	{
		empName = "Harsha";
		empAddress = "RTNagar";
		empPhone = "9383838833";
		empMail = "harsh@gmail.com";
		empSalary = 10000;
	}
	//Parameterized Constructor
	public EmployeeDetail(String empName,String empAddress,String empPhone,String empMail,int empSalary)
	{
		//TO AVOID MIRRORING -use this - is an instance of the current
	//	EmployeeDetail ed = new EmployeeDetail();
		this.empName = empName; 
		this.empAddress = empAddress;
		this.empPhone = empPhone;
		this.empMail = empMail;
		this.empSalary = empSalary;
	}
/*	public EmployeeDetail(String empName,String empAddress,String empPhone,String empMail)
	{
		this.empName = empName;
		this.empAddress = empAddress;
		this.empPhone = empPhone;
		this.empMail = empMail;
	}
	public EmployeeDetail(String empName,String empAddress,String empPhone)
	{
		this.empName = empName;
		this.empAddress = empAddress;
		this.empPhone = empPhone;

	}*/
	public void displayEmployeeDetails()
	{
		System.out.println("The Employee Details are ");
		System.out.println("Employee Name "+empName);
		System.out.println("Employee Address "+empAddress);
		System.out.println("Employee Phone "+empPhone);
		System.out.println("Employee Mail "+empMail);
		System.out.println("Employee Salary "+empSalary);
	}
	// GETTERS - SETTERS
	//ARRAY 1D 2D JAGGEDARRAY VARARGS CMD LINE
	//EXCEPTION HANDLING
	public static void main(String[] args)
	{
	EmployeeDetail emp1 = new EmployeeDetail();
	emp1.displayEmployeeDetails();
	System.out.println("--------------------------");
	EmployeeDetail emp2 = new EmployeeDetail("Kiran Kumar","Malleswaram","9838383883","kira@gmail.com",20000);
	emp2.displayEmployeeDetails();
/*	System.out.println("--------------------------");
	EmployeeDetail emp3 = new EmployeeDetail("Kiran Kumar","Malleswaram","9838383883","kira@gmail.com");
	emp3.displayEmployeeDetails();
	System.out.println("--------------------------");
	EmployeeDetail emp4 = new EmployeeDetail("Kiran Kumar","Malleswaram","9838383883");
	emp4.displayEmployeeDetails();*/
		
	}

}
