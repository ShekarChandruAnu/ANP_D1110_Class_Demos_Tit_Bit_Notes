package com.anu.poly;
class BaseClass
{
	public void display1()
	{
		System.out.println("Displaying Base Classe Features...");
	}
}
class DerivedClass extends BaseClass
{
	//ANNOTATIONS indicator which gives information to the compiler how the following lines shoudl be treated
	
	public void display2()
	{
		System.out.println("Displaying Derived Class Features...");
	}
}
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DerivedClass dc  = new DerivedClass();
		dc.display1();
		dc.display2();

	}

}
