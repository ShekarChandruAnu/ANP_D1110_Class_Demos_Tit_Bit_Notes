package com.anu.poly2;

public interface Account extends CreditCard,DebitCard{

	public void openAccount();
	public void closeAccount();
}
