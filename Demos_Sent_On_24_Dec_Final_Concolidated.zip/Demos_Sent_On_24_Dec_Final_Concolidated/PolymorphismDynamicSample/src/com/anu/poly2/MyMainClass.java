package com.anu.poly2;

public class MyMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyAccount mac = new MyAccount();
		mac.openAccount();
		mac.calculateOutstandingAmt();
		mac.calculateInterest();
		mac.calculateRedemptionPoints();
		
		mac.deposit();
		mac.withdraw();
		mac.viewTransactions();
		
		mac.openPolicy();
		mac.terminatePolicy();
		mac.calculatePremium();
		mac.closeAccount();

	}

}
