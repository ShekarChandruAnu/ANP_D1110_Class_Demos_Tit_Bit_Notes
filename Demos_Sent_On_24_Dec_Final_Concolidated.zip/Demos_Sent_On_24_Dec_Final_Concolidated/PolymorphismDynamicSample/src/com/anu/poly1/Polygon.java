package com.anu.poly1;

public class Polygon extends Shapes{

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Drawing Polygons..");
	}

}
