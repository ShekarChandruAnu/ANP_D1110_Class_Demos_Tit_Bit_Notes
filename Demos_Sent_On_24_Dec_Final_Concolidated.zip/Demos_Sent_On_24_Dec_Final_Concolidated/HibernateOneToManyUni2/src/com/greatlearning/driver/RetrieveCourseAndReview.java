
package com.greatlearning.driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.greatlearning.entity.Course;
import com.greatlearning.entity.Review;
import com.greatlearning.entity.Teacher;
import com.greatlearning.entity.TeacherDetails;


public class RetrieveCourseAndReview {


	public static void main(String[] args) {

		// create session factory
		SessionFactory factory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Teacher.class)
				.addAnnotatedClass(TeacherDetails.class)
				.addAnnotatedClass(Course.class)
				.addAnnotatedClass(Review.class)
				.buildSessionFactory();

		// create session
		Session session = factory.getCurrentSession();

		try {

			// start transaction
		session.beginTransaction();

			//get the Course
		/*	int theCourseId = 12;
			Course tempCourse =session.get(Course.class,theCourseId);
			System.out.println("Course :" + tempCourse);
			
			Teacher teacher = tempCourse.getTeacher();
			System.out.println("The Corresponding Teacher is "+teacher);
	
			
			//get reviews of Course
			System.out.println("Reviews "+tempCourse.getReviews());
			System.out.println("For the Above Course and Teacher");
			session.getTransaction().commit();

			System.out.println("Completed Successfully"); 	*/
			System.out.println("-------------");
		//	session.beginTransaction();
			
			int theCourseId1 = 18;
			Course tempCourse1 =session.get(Course.class,theCourseId1);
			System.out.println("Course :" + tempCourse1);
			
			Teacher teacher1 = tempCourse1.getTeacher();
			System.out.println("The Corresponding Teacher is "+teacher1);
	
			
			//get reviews of Course
			System.out.println("Reviews "+tempCourse1.getReviews());
			System.out.println("For the Above Course and Teacher");
			session.getTransaction().commit();



		} finally {
			//add a clean up code
			session.close();

			factory.close();
		}
	}
}


