package com.anu.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.anu.connect.MyConnection;
import com.anu.model.Employee;



public class SampleJdbc {

	Connection con;
	Statement stmt;
	PreparedStatement pstmt;
	ResultSet rs;
	String url = "jdbc:mysql://localhost:3306/ctsdata";
	String user = "root";
	String password ="MySQL_@123456";
	MyConnection mycon ;
	public SampleJdbc()
	{
		mycon = new MyConnection();
	}
	
	public void getEmployeeData()
	{
		try {
			
			con = mycon.getMyConnection();
			//Create Statement
			Statement stmt = con.createStatement();
			//Execute Query
		ResultSet rs =  stmt.executeQuery("select * from employee");
		//Handle ResultSet
		System.out.println("EmployeeId : EmployeeName : Address : Phone : Salary : Tax");
		while(rs.next())
		{
			System.out.println(rs.getString(1)+" : "+rs.getString(2)+" : "+rs.getString(3)+ " : "+rs.getString(4)+" : "+rs.getInt(5)+" : "+rs.getFloat(6));
		}
			//Handle Exception
		} catch(SQLException sqe) {
			sqe.printStackTrace();
		}
		
	}
	public void insertEmployee(Employee employee)
	{
		con = mycon.getMyConnection();
		String query = "insert into Employee values(?,?,?,?,?,?)";
		try {
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, employee.getEmpId());
			pstmt.setString(2, employee.getEmpName());
			pstmt.setString(3, employee.getEmpAddress());
			pstmt.setString(4, employee.getEmpPhone());
			pstmt.setInt(5, employee.getEmpSalary());
			pstmt.setFloat(6, employee.getEmpTax());
			
			pstmt.execute();
			System.out.println("Employee Record Inserted Successfully....");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Employee Record Insertion Failed...");
		}
		
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SampleJdbc sjdbc = new SampleJdbc();
		Employee employee1 = new Employee("E015","Mahendra Kumar","Yashwanthapura","7489949949",15000,12.34f);
		sjdbc.insertEmployee(employee1);
		sjdbc.getEmployeeData();

	}

}
