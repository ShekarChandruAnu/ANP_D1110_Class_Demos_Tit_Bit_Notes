package com.anu.coll;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

public class VectorSample {

	Vector <Employee> myVector = new Vector(5,2);
	public void PopulateVector()
	{
		
	/*	myVector.add(new Employee("E001","Mahesh","9849932244","Jayanagar",13000));
		myVector.add(new Employee("E002","Mallesh","9849943244","Malleswaram",11000));
		myVector.add(new Employee("E003","Ashok Kumar","9845679944","Koramangala",12000));
		myVector.add(new Employee("E004","Vandana","9849932144","Vijayanagar",14000));
		myVector.add(new Employee("E005","Kiran Kumar","9849949944","RTNagar",10000));
		myVector.add(new Employee("E006","SreeKumar","9846549944","Indiranagar",10500)); */
		
		//myVector.addElement(obj);
		myVector.addElement(new Employee("E001","Mahesh","9849932244","Jayanagar",13000));
		myVector.addElement(new Employee("E002","Mallesh","9849943244","Malleswaram",11000));
		myVector.addElement(new Employee("E003","Ashok Kumar","9845679944","Koramangala",12000));
		myVector.addElement(new Employee("E004","Vandana","9849932144","Vijayanagar",14000));
		myVector.addElement(new Employee("E005","Kiran Kumar","9849949944","RTNagar",10000));
		myVector.addElement(new Employee("E006","SreeKumar","9846549944","Indiranagar",10500));
		System.out.println("Current Size "+myVector.size());
		System.out.println("Current Capacity "+myVector.capacity());
		myVector.addElement(new Employee("E007","Kishan","9569949944","RTNagar",10000));
		myVector.addElement(new Employee("E008","Sreeranjani","9846549944","Indiranagar",10500));
		System.out.println("Current Size "+myVector.size());
		System.out.println("Current Capacity "+myVector.capacity());
		myVector.addElement(new Employee("E009","Manu","9569943944","RTNagar",10000));
		myVector.addElement(new Employee("E010","Rajan","9842319944","Indiranagar",10500));
		myVector.addElement(new Employee("E011","Suman","9846546544","Indiranagar",10500));
		System.out.println("Current Size "+myVector.size());
		System.out.println("Current Capacity "+myVector.capacity());
	}
	public void fetchVectorObjects()
	{
		Iterator <Employee> empVectorIter = myVector.iterator();
		while(empVectorIter.hasNext())
		{
			Employee employee = empVectorIter.next();
			System.out.println("The Element is "+employee);
		}
	}
	public void fetchVectorThruEnum()
	{
		Enumeration <Employee> empEnum = myVector.elements();
		while(empEnum.hasMoreElements())
		{
			Employee emp = empEnum.nextElement();
			System.out.println(emp);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VectorSample vsamp = new VectorSample();
		vsamp.PopulateVector();
		//vsamp.fetchVectorObjects();
		vsamp.fetchVectorThruEnum();

	}

}
