package com.anu.coll;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListSample {
	
	ArrayList myList = new ArrayList();
	public void manipulateArrayList()
	{
		myList.add("Hello World");
		myList.add(true);
		myList.add(100020020L); // typeOf
		myList.add(3455.678866d);
		myList.add(3445.567f);
		myList.add(192929);
		
		System.out.println("-------Display through For-each------");
		for(Object obj:myList)
		{
			System.out.println("List element is "+obj);
		}
		System.out.println("------------Display Objects Directly-------------");
		System.out.println(myList);
		System.out.println("---------Display Thru Iterator---------");
		Iterator listIter = myList.iterator();
		while(listIter.hasNext())
		{
			System.out.println(listIter.next());
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayListSample als = new ArrayListSample();
		als.manipulateArrayList();
		

	}

}
