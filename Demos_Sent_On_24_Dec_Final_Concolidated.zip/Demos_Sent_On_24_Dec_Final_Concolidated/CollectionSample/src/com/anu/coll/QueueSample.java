package com.anu.coll;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueSample {

	Queue <String> myQueue = new PriorityQueue<String>();
	Queue <Employee> employeeQ = new PriorityQueue<Employee>();
	public void enqueueQueue()
	{
		myQueue.add("Amarendra");
		myQueue.add("Brajesh");
		myQueue.add("Chandan");
		myQueue.add("David");
		myQueue.add("Emanuel");
		myQueue.add("Faheem");
	}
	
	public void dequeueuQueue()
	{
		while(myQueue.isEmpty() == false)
		{
			System.out.println("The Dequeued Element is "+myQueue.remove());
		}
		
	}
	public void enqueueEmployeeQ()
	{
		//FIFO COMPARATOR & COMPARABLE
		employeeQ.add(new Employee("E001","Mahesh","9849932244","Jayanagar",13000));
		employeeQ.add(new Employee("E002","Mallesh","9849943244","Malleswaram",11000));
		employeeQ.add(new Employee("E003","Ashok Kumar","9845679944","Koramangala",12000));
		employeeQ.add(new Employee("E004","Vandana","9849932144","Vijayanagar",14000));
		employeeQ.add(new Employee("E005","Kiran Kumar","9849949944","RTNagar",10000));
		employeeQ.add(new Employee("E006","SreeKumar","9846549944","Indiranagar",10500));
	}
	public void dequeueEmployeeQ()
	{
		while(employeeQ.isEmpty() == false)
		{
			System.out.println("The Dequeued Employee  is "+employeeQ.remove());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		QueueSample qSample = new QueueSample();
	/*	qSample.enqueueQueue();
		qSample.dequeueuQueue();*/
		qSample.enqueueEmployeeQ();
		qSample.dequeueEmployeeQ();

	}

}
