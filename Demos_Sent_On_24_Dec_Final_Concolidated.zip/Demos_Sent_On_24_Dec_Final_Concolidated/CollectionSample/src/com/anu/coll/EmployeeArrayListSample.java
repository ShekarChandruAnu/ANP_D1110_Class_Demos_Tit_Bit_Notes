package com.anu.coll;

import java.util.ArrayList;
import java.util.Iterator;

public class EmployeeArrayListSample {

	ArrayList <Employee> employees = new ArrayList<Employee>();
	public void manipulateGenArrayList()
	{
		Employee emp1 = new Employee("E001","Rakesh Kumar","9389393993","KRPuram",10000);
		employees.add(emp1);
		employees.add(new Employee("E002","Rajesh Kumar","9546393993","RSPuram",15000));
		employees.add(new Employee("E003","Sumanth Kumar","9432293993","Koramangala",18000));
		employees.add(new Employee("E004","Suman Kumar","9546393673","Vijayanagar",19000));
		employees.add(new Employee("E005","Pallavi","9546393783","Jayanagar",20000));
		employees.add(new Employee("E006","Tejas","9546393323","Malleswaram",24000));
		employees.add(new Employee("E007","Indu","9546393123","Koramangala",25000));
		employees.add(3, new Employee("E003a","Murali Krishna","9545463673","Malleswaram",21000));
		//employees.add(283993949l); NOT ALLOWED
		
	}
	public void displayGenArrayList()
	{
		Iterator <Employee> empIter = employees.iterator();
		while(empIter.hasNext())
		{
			Employee employee = empIter.next();
			System.out.println(employee);
		}
		System.out.println("AT 4 "+employees.get(4));
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeArrayListSample eals = new EmployeeArrayListSample();
		eals.manipulateGenArrayList();
		eals.displayGenArrayList();

	}

}
