package com.anu.coll;

import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

public class HashTableSample {

	// Key: EmpCode E001...2...3...  Value: Object Employee
	Hashtable <String, Employee> hTable = new Hashtable<String,Employee>();
	public void populateHashTable()
	{
		hTable.put("E005", new Employee("E005","Kiran Kumar","9849949944","RTNagar",10000));
		hTable.put("E003", new Employee("E003","Ashok Kumar","9845679944","Koramangala",12000));
		hTable.put("E002", new Employee("E002","Mallesh","9849943244","Malleswaram",11000));
		hTable.put("E006", new Employee("E006","SreeKumar","9846549944","Indiranagar",10500));
		hTable.put("E004", new Employee("E004","Vandana","9849932144","Vijayanagar",14000));
		hTable.put("E001", new Employee("E001","Mahesh","9849932244","Jayanagar",13000));
		
	}
	public void fetchHashTableData()
	{
		Enumeration <String> keyEnumer = hTable.keys();
	
		while(keyEnumer.hasMoreElements())
		{
			String myKey = keyEnumer.nextElement();
			System.out.println("The Value for the Key "+myKey+" is :"+hTable.get(myKey));
		}
	}
	public void fetchHashTableValues()
	{
		Collection <Employee> employees = hTable.values();
		
		Iterator <Employee> valueIter = employees.iterator();
		while(valueIter.hasNext())
		{
			System.out.println(valueIter.next());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashTableSample hts = new HashTableSample();
		hts.populateHashTable();
		hts.fetchHashTableData();
		System.out.println("---------Values alone retrieved-----------");
		hts.fetchHashTableValues();

	}

}
