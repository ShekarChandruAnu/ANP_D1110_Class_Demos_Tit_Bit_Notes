package com.anu.coll;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class HashSetTreeSetSample {

	HashSet <String> hSet = new HashSet<String>();
	TreeSet <String> tSet = new TreeSet<String>();
	
	public void populateHashSet()
	{
		hSet.add("Faridabad");
		hSet.add("Mumbai");
		hSet.add("Delhi");
		hSet.add("Coimbatore");
		hSet.add("Hyderabad");
		hSet.add("Ernakulam");
		hSet.add("Bangalore");
		hSet.add("Bangalore");
		
		
	}
	public void fetchHashSet()
	{
		Iterator <String> setIter = hSet.iterator();
		System.out.println("The Hash Set Elements ");
		while(setIter.hasNext())
		{
			//String city = setIter.next()
			System.out.println(setIter.next());
		}
	}
	public void populateTreeSet()
	{
		tSet.add("Faridabad");
		tSet.add("Mumbai");
		tSet.add("Delhi");
		tSet.add("Coimbatore");
		tSet.add("Hyderabad");
		tSet.add("Ernakulam");
		tSet.add("Bangalore");
		tSet.add("Bangalore");
		tSet.add("bangalore");
		
	}
	public void fetchTreeSet()
	{
		Iterator <String> tSetIter = tSet.iterator();
		System.out.println("The Tree Set Elements ");
		while(tSetIter.hasNext())
		{
			System.out.println(tSetIter.next());
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSetTreeSetSample hsts = new HashSetTreeSetSample();
		hsts.populateHashSet();
		hsts.fetchHashSet();
		System.out.println("-----------");
		hsts.populateTreeSet();
		hsts.fetchTreeSet();

	}

}
