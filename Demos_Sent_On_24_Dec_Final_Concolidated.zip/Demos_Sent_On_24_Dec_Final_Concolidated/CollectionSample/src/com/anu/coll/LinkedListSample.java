package com.anu.coll;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListSample {

	LinkedList <Employee> employeesLL = new LinkedList<Employee>();
	
	public void populateLinkedList()
	{
		Employee emp1 = new Employee("E001","Rakesh Kumar","9389393993","KRPuram",10000);
		employeesLL.add(emp1);
		employeesLL.add(new Employee("E002","Rajesh Kumar","9546393993","RSPuram",15000));
		employeesLL.add(new Employee("E003","Sumanth Kumar","9432293993","Koramangala",18000));
		employeesLL.add(new Employee("E004","Suman Kumar","9546393673","Vijayanagar",19000));
		employeesLL.add(new Employee("E005","Pallavi","9546393783","Jayanagar",20000));
		employeesLL.add(new Employee("E006","Tejas","9546393323","Malleswaram",24000));
		employeesLL.add(new Employee("E007","Indu","9546393123","Koramangala",25000));
		employeesLL.add(3, new Employee("E003a","Murali Krishna","9545463673","Malleswaram",21000));
		employeesLL.addFirst(new Employee("E001a","Mohan Kumar","9849499494","Koramangala",23000));
		employeesLL.addLast(new Employee("E008","Srujan","8758588585","Malleswaram",34000));
	}
	public void displayLinkedList()
	{
		Iterator <Employee> empLLIter = employeesLL.iterator();
		while(empLLIter.hasNext())
		{
			Employee employee  = empLLIter.next();
			System.out.println(employee);
		}
		System.out.println("At 4 "+employeesLL.get(4));
		System.out.println("At First "+employeesLL.getFirst());
		
	}
	public void displayLinkedListDescending()
	{
		Iterator <Employee> empDescIter = employeesLL.descendingIterator();
		while(empDescIter.hasNext())
		{
			Employee employee = empDescIter.next();
			System.out.println(employee);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedListSample lls = new LinkedListSample();
		lls.populateLinkedList();
		lls.displayLinkedList();
		System.out.println("-----");
		lls.displayLinkedListDescending();

	}

}
