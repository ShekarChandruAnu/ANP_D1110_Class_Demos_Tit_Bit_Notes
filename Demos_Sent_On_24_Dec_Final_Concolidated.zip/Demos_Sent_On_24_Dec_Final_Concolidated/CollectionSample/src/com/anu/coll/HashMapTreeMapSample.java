package com.anu.coll;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class HashMapTreeMapSample {
	
	HashMap <String,Employee> hMap = new HashMap<String,Employee>();
	TreeMap <String,Employee> tMap = new TreeMap<String,Employee>();
	
	public void populateHashMap()
	{
		hMap.put("E005", new Employee("E005","Kiran Kumar","9849949944","RTNagar",10000));
		hMap.put("E003", new Employee("E003","Ashok Kumar","9845679944","Koramangala",12000));
		hMap.put("E002", new Employee("E002","Mallesh","9849943244","Malleswaram",11000));
		hMap.put("E006", new Employee("E006","SreeKumar","9846549944","Indiranagar",10500));
		hMap.put("E004", new Employee("E004","Vandana","9849932144","Vijayanagar",14000));
		hMap.put("E001", new Employee("E001","Mahesh","9849932244","Jayanagar",13000));
		hMap.put("E001", new Employee("E001a","Maheshwaran","9845432244","ViJayanagar",14000));
	}
	public void fetchHashMap()
	{
		Set <String> myKeySet = hMap.keySet();
	
		
		Iterator <String> myKeyIter = myKeySet.iterator();
		while(myKeyIter.hasNext())
		{
			String myKey = myKeyIter.next();
			System.out.println("The value object for the Key "+myKey+" Is "+hMap.get(myKey));
		}
	}
	public void populateTreeMap()
	{
		tMap.put("E005", new Employee("E005","Kiran Kumar","9849949944","RTNagar",10000));
		tMap.put("E003", new Employee("E003","Ashok Kumar","9845679944","Koramangala",12000));
		tMap.put("E002", new Employee("E002","Mallesh","9849943244","Malleswaram",11000));
		tMap.put("E006", new Employee("E006","SreeKumar","9846549944","Indiranagar",10500));
		tMap.put("E004", new Employee("E004","Vandana","9849932144","Vijayanagar",14000));
		tMap.put("E001", new Employee("E001","Mahesh","9849932244","Jayanagar",13000));
	}
	
	public void fetchTreeMap()
	{
		Set <String> myKeySet = tMap.keySet();
		
		Iterator <String> myKeys = myKeySet.iterator();
		while(myKeys.hasNext())
		{
			String myKey = myKeys.next();
			System.out.println("The Value object for the Key "+myKey+" is "+tMap.get(myKey));
		}
	}
	public void fetchTreeMapDesc()
	{
		Set <String> myKeySet = tMap.descendingKeySet();
		
		Iterator <String> myKeyIter = myKeySet.iterator();
		while(myKeyIter.hasNext())
		{
			String myKey = myKeyIter.next();
			System.out.println("The value Object for the Key "+myKey+" is "+tMap.get(myKey));
		}
	}
	public void fetchTreeMapUsingEntrySet()
	{
		Set <Entry <String,Employee>> myEntrySet = tMap.entrySet();
		Iterator <Entry <String,Employee>> entrySetIter = myEntrySet.iterator();
		while(entrySetIter.hasNext())
		{
			Entry <String,Employee> myEntry = entrySetIter.next();
			System.out.println("The Key is "+myEntry.getKey()+" And Corresponding Value Object is "+myEntry.getValue());
			
		}
	}
	public void fetchTreeMapValues()
	{
		Collection <Employee> myEmployeeValues = tMap.values();
		Iterator <Employee> empValuesIter = myEmployeeValues.iterator();
		while(empValuesIter.hasNext())
		{
			Employee employee = empValuesIter.next();
			System.out.println("The Value Obejct is "+employee);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMapTreeMapSample htms = new HashMapTreeMapSample();
	/*	htms.populateHashMap();
		htms.fetchHashMap();
		System.out.println("---------------"); */
		htms.populateTreeMap();
	/*	htms.fetchTreeMap();
		System.out.println("-------- TreeMap fetched in Descending  Order--------");
		htms.fetchTreeMapDesc(); */
		htms.fetchTreeMapUsingEntrySet();
		System.out.println("-------");
		htms.fetchTreeMapValues();

	}

}
