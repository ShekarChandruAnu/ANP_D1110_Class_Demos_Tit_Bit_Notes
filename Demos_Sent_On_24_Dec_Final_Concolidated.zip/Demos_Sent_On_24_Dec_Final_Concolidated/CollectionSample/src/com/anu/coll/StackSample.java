package com.anu.coll;

import java.util.Iterator;
import java.util.Stack;

public class StackSample {

	Stack <String> myStack = new Stack<String>();
	
	public void populateStackThruPush()
	{
		/*myStack.add("Coimbatore");
		myStack.add("Hyderabad");
		myStack.add("Bangalore");
		myStack.add("Delhi");
		myStack.add("Mumbai");
		myStack.add("Ernakulam");
		myStack.add("Faridabad");*/
		myStack.push("Coimbatore");
		myStack.push("Hyderabad");
		myStack.push("Bangalore");
		myStack.push("Delhi");
		myStack.push("Mumbai");
		myStack.push("Ernakulam");
		myStack.push("Faridabad");

	}
	public void fetchStackThruPop()
	{
		System.out.println("The size Before POpping is "+myStack.size());
		while(myStack.isEmpty() == false)
		{
			String myCity = myStack.pop();
			System.out.println("The City Popped is "+myCity);
		}
		System.out.println("The size After POpping is "+myStack.size());
	}
	
	public void fetchStackThruIterator()
	{
		Iterator <String> stackIter = myStack.iterator();
		while(stackIter.hasNext())
		{
			System.out.println("The Stack Element "+stackIter.next());
		}
	}
	public void fetchStackThruRemove()
	{//6
		System.out.println("The Size Before Peeking "+myStack.size()); //
		System.out.println("The City Peeked "+myStack.peek());
		System.out.println("The Size After Peeking But before removing "+myStack.size()); //
		while(myStack.isEmpty() == false)
		{
			String cityRemoved = myStack.remove(0);
			System.out.println("GThe City Removed "+cityRemoved);
			System.out.println("The current size is "+myStack.size());
		}
		System.out.println("The Size after Removing "+myStack.size()); 
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StackSample ssample = new StackSample();
		ssample.populateStackThruPush();
		System.out.println("-----Thru Iter------");
		ssample.fetchStackThruIterator();
		System.out.println("-------Thru remove");
		ssample.fetchStackThruRemove();
		System.out.println("-----Thru Pop------");
		ssample.fetchStackThruPop();
		

	}

}
