package com.anu.sorts;

// public class MyClass extends OtherClass
//public class MyClass implements Interface1 <>
public class Employee implements Comparable <Employee>{
	
	String empId;
	String empName;
	String empCity; //compareTo
	int empSalary;
	//Integer empSalary
	public Employee() {
		super();
	}
	public Employee(String empId, String empName, String empCity, int empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empCity = empCity;
		this.empSalary = empSalary;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpCity() {
		return empCity;
	}
	public void setEmpCity(String empCity) {
		this.empCity = empCity;
	}
	public int getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empCity=" + empCity + ", empSalary=" + empSalary
				+ "]";
	}					//e2  e3	//e3  e2
	//SORT EMPID		babu amar----> amar babu
/*	@Override
	public int compareTo(Employee employee) {
		// TODO Auto-generated method stub
		if(this.getEmpId().compareTo(employee.getEmpId()) > 0)
		{
			return 1;
		}
		else if(this.getEmpId().compareTo(employee.getEmpId()) < 0)
		{
			return -1;
		}
		else
		{
			return 0;
		}
			
	}*/
	//SORT CITY
 /*	@Override
	public int compareTo(Employee employee) {
		// TODO Auto-generated method stub
		if(this.getEmpCity().compareTo(employee.getEmpCity()) > 0)
		{
			return 1;
		}
		else if(this.getEmpCity().compareTo(employee.getEmpCity()) < 0)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}*/			//	e3      e1   -->e1   e3
	//SORT SALARY  25000 > 20000   
	@Override
	public int compareTo(Employee employee) {
		// TODO Auto-generated method stub
		//Integer.compare(this.empSalary, employee.empSalary)
		if(this.getEmpSalary() > employee.getEmpSalary())
		{
			return 1;
		}
		else if (this.getEmpSalary() < employee.getEmpSalary())
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	
	

}
