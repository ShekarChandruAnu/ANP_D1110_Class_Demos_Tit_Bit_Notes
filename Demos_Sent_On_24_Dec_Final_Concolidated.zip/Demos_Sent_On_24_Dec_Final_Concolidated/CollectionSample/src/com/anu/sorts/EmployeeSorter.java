package com.anu.sorts;

import java.util.ArrayList;
import java.util.Collections;

public class EmployeeSorter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList <Employee> employees = new ArrayList<Employee>();
		employees.add(new Employee("E003","Babu","Faridabad",15000));
		employees.add(new Employee("E001","Amar","Bangalore",18000));
		employees.add(new Employee("E004","Faheem","Delhi",12000));
		employees.add(new Employee("E002","Emanuel","Ernakulam",25000));
		employees.add(new Employee("E005","Chandu","Ahmedabad",14000));
		
		Collections.sort(employees);
		System.out.println("Employee Salary  Sorted ........");
		for(Employee e:employees)
		{
			System.out.println(e);
		}

	}

}
