package com.anu.sorts1;

import java.util.ArrayList;
import java.util.Collections;

public class StudentSorter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList <Student> students = new ArrayList<Student>();
		students.add(new Student("S003","Chandigarh",87));
		students.add(new Student("S005","Bangalore",77));
		students.add(new Student("S004","Ahmedabad",67));
		students.add(new Student("S002","Ernakulam",81));
		students.add(new Student("S001","Dharwad",97));
		
		System.out.println("Student ID Sorted");
		Collections.sort(students,new IdSorter());
		for(Student student:students)
		{
			System.out.println(student);
		}
		System.out.println("-------");
		System.out.println("Student City Sorted");
		Collections.sort(students,new CitySorter());
		
		for(Student student:students)
		{
			System.out.println(student);
		}
		System.out.println("-------");
		System.out.println("Student Score Sorted");
		Collections.sort(students,new ScoreSorter());
		for(Student student:students)
		{
			System.out.println(student);
		}
		

	}

}
