package com.anu.sorts1;

import java.util.Comparator;

public class CitySorter implements Comparator <Student>{

	@Override
	public int compare(Student student1, Student student2) {
		// TODO Auto-generated method stub
		if( (student1.getStudCity().compareTo(student2.getStudCity())) > 0 )
		{
			return 1;
		}
		else if (student1.getStudCity().compareTo(student2.getStudCity()) < 0)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}

}
