package com.anu.sorts1;

import java.util.Comparator;

public class ScoreSorter implements Comparator <Student> {

	@Override
	public int compare(Student student1, Student student2) {
		// TODO Auto-generated method stub
		if(student1.getStudScore() > student2.getStudScore())
		{
			return -1;
		}
		else if(student1.getStudScore() < student2.getStudScore())
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	

}
