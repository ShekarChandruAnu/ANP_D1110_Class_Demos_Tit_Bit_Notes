package com.anu.sorts1;

public class Student {
	
	String studId;
	String studCity;
	int studScore;
	
	public Student() {
		super();
	}

	public Student(String studId, String studCity, int studScore) {
		super();
		this.studId = studId;
		this.studCity = studCity;
		this.studScore = studScore;
	}

	public String getStudId() {
		return studId;
	}

	public void setStudId(String studId) {
		this.studId = studId;
	}

	public String getStudCity() {
		return studCity;
	}

	public void setStudCity(String studCity) {
		this.studCity = studCity;
	}

	public int getStudScore() {
		return studScore;
	}

	public void setStudScore(int studScore) {
		this.studScore = studScore;
	}

	@Override
	public String toString() {
		return "Student [studId=" + studId + ", studCity=" + studCity + ", studScore=" + studScore + "]";
	}
	
	

}
