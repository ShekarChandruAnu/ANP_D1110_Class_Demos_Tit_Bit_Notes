package com.anu.files;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamSample {

	FileOutputStream  fos;
	String str ="This data is written into the file through Binary Stream";
	byte[] mybytes = new byte[100];
	public void writeToBinaryStream()
	{
		mybytes = str.getBytes();
		
		try {
			fos = new FileOutputStream("customer.txt");
			fos.write(mybytes);
			fos.flush();
			fos.close();
			System.out.println("Written Data into Binary Stream successfully...");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileOutputStreamSample foss = new FileOutputStreamSample();
		foss.writeToBinaryStream();

	}

}
