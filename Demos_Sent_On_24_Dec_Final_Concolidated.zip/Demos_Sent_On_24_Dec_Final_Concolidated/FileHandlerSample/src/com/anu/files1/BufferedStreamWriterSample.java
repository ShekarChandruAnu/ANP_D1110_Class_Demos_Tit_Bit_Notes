package com.anu.files1;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedStreamWriterSample {

	BufferedOutputStream bos;
	String str = "We are writing to Stream through Buffer";
	byte mybytes[] = new byte[100];
	public void writeToStreamThruBuffer()
	{
	/*	FileOutputStream fos = new FileOutputStream("Dealers.txt");
		bos = new BufferedOutputStream(fos);*/
		try {
			mybytes = str.getBytes();
			bos = new BufferedOutputStream(new FileOutputStream("Dealers.txt"),100000);
			//bos = new BufferedOutputStream(new FileOutputStream("Dealers.txt"),100000);
			bos.write(mybytes);
			bos.flush();
			bos.close();
			System.out.println("We wrote data to Stream through buffer successfully...");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedStreamWriterSample bsws = new BufferedStreamWriterSample();
		bsws.writeToStreamThruBuffer();

	}

}
