package com.anu.files1;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class DataOutputStreamSample {

	DataOutputStream dos;
	DataInputStream dis;
	public void writeUsingDataOutputStream()
	{
		try {
			dos = new DataOutputStream(new FileOutputStream("employees.txt"));
			dos.writeUTF("Hello World");
			dos.writeFloat(234.567f);
			dos.writeDouble(123.456789d);
			dos.writeInt(20000);
			dos.writeLong(29292992992L);
			dos.writeBoolean(true);
			
			dos.flush();
			dos.close();
			System.out.println("Written USing DataOutputStream..");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  catch(IOException ioe)	{
			ioe.printStackTrace();
		}
	}
	public void readUsingDataInputStream()
	{
		try {
			dis = new DataInputStream(new FileInputStream("employees.txt"));
			System.out.println("The String Data Read "+dis.readUTF());
			System.out.println("The Float Data Read "+dis.readFloat());
			System.out.println("The Double Data Read "+dis.readDouble());
			System.out.println("The Integer Data Read "+dis.readInt());
			System.out.println("The Long Data Read "+dis.readLong());
			System.out.println("The Boolean Data read "+dis.readBoolean());
			dis.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DataOutputStreamSample dots = new DataOutputStreamSample();
		//dots.writeUsingDataOutputStream();
			dots.readUsingDataInputStream();
	}

}
