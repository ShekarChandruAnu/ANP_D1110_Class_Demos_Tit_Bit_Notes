package com.anu.threads;
class MultiThread implements Runnable
{
	Thread t1;
	String chThreadName;
	public MultiThread(String chThreadName)
	{
		this.chThreadName = chThreadName;
		t1 = new Thread(this,chThreadName);
		t1.start();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<5;i++)
		{
			System.out.println(t1+ " Loop "+(i+1));
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
}
public class MultipleThreads {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In The Main Thread....");
		System.out.println("About to Invoke Child Threads.....");
		MultiThread mt1 = new MultiThread("ChildThread 01");
		MultiThread mt2 = new MultiThread("ChildThread 02");
		MultiThread mt3 = new MultiThread("ChildThread 03");
		for(int i=0;i<5;i++)
		{
			System.out.println("Main Thread Loop "+(i+1));
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Back in The Main Thread , Exiting Main Thread");

	}

}
