package com.anu.threads;

public class MainThreadSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread mainThread = Thread.currentThread();
		System.out.println("Main Thread "+mainThread);
		mainThread.setName("New Main Thread");
		System.out.println("Thread AFter Name Change "+mainThread);

	}

}
