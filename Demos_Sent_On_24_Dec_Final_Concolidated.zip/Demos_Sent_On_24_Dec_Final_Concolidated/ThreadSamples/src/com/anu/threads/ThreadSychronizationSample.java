package com.anu.threads;
class Thread10
{
	public /*synchronized*/ void call()
	{
		System.out.println("Produce Goods...");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Consumed Goods...");
	}
}
class MyThread3 extends  Thread
{
Thread10 t10;
	public MyThread3(Thread10 t10)
	{
		this.t10 = t10;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		synchronized(t10)
		{
		t10.call();
		}
		/*
		 * NON SYNCHRONIZED
		 */
	}
	
}
public class ThreadSychronizationSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In The Main Thread...");
		Thread10 th10 = new Thread10();
		
		MyThread3 mt3a = new MyThread3(th10);
		MyThread3 mt3b = new MyThread3(th10);
		MyThread3 mt3c = new MyThread3(th10);
		mt3a.start();
		mt3b.start();
		mt3c.start();
		
		
		

	}

}
