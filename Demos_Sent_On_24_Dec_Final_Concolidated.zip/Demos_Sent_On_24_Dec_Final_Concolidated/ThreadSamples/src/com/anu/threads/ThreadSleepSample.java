package com.anu.threads;
class MyThread2 implements Runnable
{
	Thread t1;
	public MyThread2()
	{
		t1 = new Thread(this,"ChildThread");
		System.out.println("Child Thread "+t1);
		t1.start();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("In The Child Thread...");
		for(int i=0;i<5;i++)
		{
			System.out.println("Child Thread Loop "+(i+1));
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
}
public class ThreadSleepSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In The Main Thread....");
		System.out.println("About to invoke Child Thread....");
		MyThread2 mt2 = new MyThread2();
		System.out.println("Is Child Thread Alive "+mt2.t1.isAlive());
		try {
			mt2.t1.join();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println("Is Child Thread Still Alive "+mt2.t1.isAlive());
		for(int i=0;i<5;i++)
		{
			System.out.println("Main Thread Loop "+(i+1));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Back In Main Thread,Exiting Main Thread.... ");

	}

}
