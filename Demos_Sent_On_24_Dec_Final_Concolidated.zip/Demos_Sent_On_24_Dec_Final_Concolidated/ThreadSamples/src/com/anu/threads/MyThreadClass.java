package com.anu.threads;
class MyThread1 extends Thread
{
	public MyThread1()
	{
		System.out.println("Child Thread "+this);
		start();
	}
	public void run()
	{
		System.out.println("In the Child  Thread");
		System.out.println("Implementing Child Thread Activities...");
		System.out.println("Exiting Child Thread...");
	}
}
public class MyThreadClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In the Main Thread...");
		System.out.println("About to invoke Child Thread...");
		MyThread1 mt1 = new MyThread1();
		System.out.println("Back in the Main Thread, Exiting Main Thread");

	}

}
