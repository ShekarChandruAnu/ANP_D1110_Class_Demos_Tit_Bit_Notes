package com.anu.except;

public class CalculatorSample {

	public void calculate(int num1,int num2)
	{
		int result =0;
		System.out.println("We are about to Calculate...");
		try
		{
			result = num1 / num2;
		}
		catch(ArithmeticException ae)
		{
			//System.out.println(ae.getMessage());
			ae.printStackTrace();
		}
		System.out.println("The Result is "+result);
		System.out.println("We are exiting the Calculator Function...");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("In the Main Method....");
		System.out.println("We are about to invoke the Calculator Method...");
		CalculatorSample calci = new CalculatorSample();
		/*try
		{*/
			calci.calculate(100, 50);
			calci.calculate(100, 25);
			calci.calculate(100, 0);
			calci.calculate(100, 10);
			calci.calculate(100, 5);
		/*}
		catch(ArithmeticException ae)
		{
			System.out.println(ae.getMessage());
		}*/
		System.out.println("Exiting the Main Method...");

	}

}
