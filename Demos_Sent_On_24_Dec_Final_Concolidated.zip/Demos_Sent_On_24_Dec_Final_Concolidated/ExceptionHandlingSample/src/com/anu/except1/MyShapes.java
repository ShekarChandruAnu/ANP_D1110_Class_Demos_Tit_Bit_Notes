package com.anu.except1;
class Shapes
{
	
	public void draw()
	{
		
	}
}
class Rectangle extends Shapes
{
	@Override
	public void draw()
	{
		System.out.println("Drawing Rectangles");
	}
}
class Triangle extends Shapes
{
	@Override
	public void draw()
	{
		System.out.println("Drawing Traingles..");
	}
}
public class MyShapes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shapes sh;
		sh = new Rectangle();
		sh.draw();
		
		sh = new Triangle();
		sh.draw();
		
		Rectangle rc = (Rectangle) new Shapes();

	}

}
