package com.anu.except1;

public class RecruitmentClass {
	
	public void callCheckAge(int age)
	{
		try
		{
			checkAge(age);
		}
		catch(InvalidAgeException iae)
		{
			System.out.println(iae.message);
			iae.printStackTrace();
		}
	}
	
	public void checkAge(int age) throws InvalidAgeException
	{
		System.out.println("In the Recruitment Process...");
		System.out.println("Age Scrutinization started...");
		System.out.println("AGe is "+age);
		if (age < 20 || age > 30)
		{
			// InvalidAgeException iae = new InvalidAgeException("Sorry Valid age is 20-30");
			throw new InvalidAgeException("Sorry Valid age is 20-30");// ANONYMOUS OBJECTS
			/* iae
			 * 
			 * 
			 * 
			 * 
			 */
		}
		else
		{
			System.out.println("Valid Age Age Scrutiny is completed");
			System.out.println("Recruitment process to continue..");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Recruitment Process Started....");
		System.out.println("Age Scrutiny to be done....");
		RecruitmentClass rc = new RecruitmentClass();
		/*try
		{*/
			rc.callCheckAge(23);//valid
			rc.callCheckAge(24);//valid
			rc.callCheckAge(34); //invalid throws exception
			rc.callCheckAge(21); // valid
			rc.callCheckAge(27); // valid
		/*}
		catch(InvalidAgeException iae)
		{
			System.out.println(iae.message);
			iae.printStackTrace();
		}*/
		System.out.println("Age Scrutiny completed ....");
		System.out.println("We Finished Recruitment Process..");

	}

}
