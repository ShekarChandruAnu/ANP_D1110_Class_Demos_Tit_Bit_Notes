package com.gl.deletion;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.gl.entity.Customer;

public class DeleteCustomer {
	
	public static void main(String[] args)
	{
		SessionFactory sFactory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Customer.class)
				.buildSessionFactory();

		Session session = sFactory.getCurrentSession();
		int id = 7;
		//Deleting Persistent Object
		try
		{
			//STARTING TRANSACTION TO DELETE USING PERSISTENT OBJECT
		session.beginTransaction();
			Customer customer = session.get(Customer.class, id);
			session.delete(customer);
			System.out.println("The Record deleted for Customer with Id "+id);
			session.getTransaction().commit(); /*	*/
			
			//New session to delete using CREATEQUERY
			Session session1 = sFactory.getCurrentSession();
			session1.beginTransaction();
			session1.createQuery("delete from Customer where id = 10").executeUpdate();
			System.out.println("Record deleted for Customer with id 10");
			session1.getTransaction().commit();
			
			
		}
		finally
		{
			sFactory.close();
		}
		
		
	}

}
