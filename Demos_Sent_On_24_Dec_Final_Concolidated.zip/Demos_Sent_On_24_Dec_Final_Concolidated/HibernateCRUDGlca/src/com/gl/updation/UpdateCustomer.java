package com.gl.updation;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.gl.entity.Customer;

public class UpdateCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		SessionFactory sFactory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Customer.class)
				.buildSessionFactory();

		Session session = sFactory.getCurrentSession();
		try
		{
			int cid = 1;
			session.beginTransaction();
				Customer customer =  session.get(Customer.class, cid);
				//Updating the Customer Name with id 1 
					customer.setCustomerName("Harsha Vardhana");
				System.out.println("The Customer With Id "+cid+" is "+customer);
			
			session.getTransaction().commit();
			
			
			Session session1 = sFactory.getCurrentSession();
			session1.beginTransaction();
				Customer custUpdated = session1.get(Customer.class, customer.getId());
			
					System.out.println("The Updated Record is"+custUpdated);
			session1.getTransaction().commit();
			
			Session session2 = sFactory.getCurrentSession();
			session2.beginTransaction();
		//	Query query=session2.createQuery("update Customer set customerAddress = 'RTNAGAR' where id= 2 ");
			session2.createQuery("update Customer set customerAddress = 'RTNAGAR' where id= 2 ").executeUpdate();
			System.out.println("The Record modified for Customer with Id 2");
			session2.getTransaction().commit();
			
			
			
			
		}
		finally
		{
			sFactory.close();
		}
	}

}
