package com.gl.insertion;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.gl.entity.Customer;

public class InsertCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SessionFactory sFactory = new Configuration()
									.configure("hibernate.cfg.xml")
									.addAnnotatedClass(Customer.class)
									.buildSessionFactory();
		
		Session session = sFactory.getCurrentSession();
		try
		{
			session.beginTransaction();
				Customer cust1 = new Customer("SMohan","Malleswaram","746746484",16000);
				Customer cust2 = new Customer("RKishan","Gandhinagar","789878484",15500);
				Customer cust3 = new Customer("TMilan","Koramangala","748879874",17000);
				session.save(cust1);
				session.save(cust2);
				session.save(cust3);
				System.out.println("Inserted Record for Id "+cust1.getId());
				System.out.println("Inserted Record for Id "+cust2.getId());
				System.out.println("Inserted Record for Id "+cust3.getId());
				System.out.println("Inserted Records Successfully");
			session.getTransaction().commit();
			//select * from Customer where customerId = 3
			
			
		}
		finally
		{
			sFactory.close();
		}

	}

}
