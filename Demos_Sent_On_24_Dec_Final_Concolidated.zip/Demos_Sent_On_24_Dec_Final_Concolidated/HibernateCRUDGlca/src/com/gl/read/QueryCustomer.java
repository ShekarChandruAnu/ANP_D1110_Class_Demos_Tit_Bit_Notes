package com.gl.read;

import java.math.BigDecimal;
import java.util.List;

//import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.gl.entity.Customer;

public class QueryCustomer {
	
	/*
	 * ----> createQuery like  /list  returns Query
	----> createQuery > operator  /list
	----> createQuery > operator and < operator  /list
	----> createQuery > operator and like  /list
	----> createQuery > operator or like  /list
	----> createSQLQuery/createQuery  - select max(column) from table1 - int x  = (int) query.uniqueResult()
		returns SqlQuery
	----> createSQLQuery /createQuery  - select min(column) from table1 - query.uniqueResult()
	----> createSQLQuery /createQuery  - select avg(column) from table1 - query.uniqueResult()
	----> createSQLQuery /createQuery  - select count(*) from table1 - query.uniqueResult()
	----> createQuery(hql) - select * from table1 where column1 = value with single record
		Object obj =  (Object)query.uniqueResult()
	----> createSQLQuery - select a,b,c,d from customer / List <Object[]> data / for(Object o: data)/o[0] o[1] %s %s printf
	----> createQuery  with like address like :par1 and purchvalue > :par2 / query.setParameter("par1",value) / list 
	----> createQuery  with like address like ?0 and purchvalue > ?1 / query.setParameter(0,value) / list 
	----> createQuery  with purchaseValue between :min1 and :max1 / query.setParameter("min1",value) / list
	----> createQuery  with purchaseValue between :min1 and :max1 / query.setParameter("min1",value) / list with order by field1 desc
	 */
	public static void main(String[] args)
	{
		SessionFactory sFactory = new Configuration()
									.configure("hibernate.cfg.xml")
									.addAnnotatedClass(Customer.class)
									.buildSessionFactory();
		
		Session session = sFactory.getCurrentSession();
		
		try
		{
			//Query Using Like Operator
				session.beginTransaction();
				//Fetching records with address ending with nagar
				System.out.println("Records with address ending with nagar");
				//Customer represents Table Name or Class Name?----->
				//customerAddress represents Table Column or Class Field?--->
				List <Customer> customers = session.createQuery("from Customer where customerAddress like '%nagar' ").list();
				displayCustomers(customers);
				
				//Fetching records with Purchase Value > 10000
				System.out.println("Records with purchase Value > 10000");
				List <Customer> customers1 = session.createQuery("from Customer where purchaseValue > 10000 ").list();
				displayCustomers(customers1);
				
				//Fetching records with and operator
				System.out.println("Records with address ending with nagar and purchase value > 10000");
				List <Customer> customers2 = session.createQuery("from Customer where purchaseValue > 10000 and customerAddress like '%nagar' ").list();
				displayCustomers(customers2);
				
				//Fetching records with or operator
				System.out.println("Records with address ending with nagar or purchase value > 10000");
				List <Customer> customers3 = session.createQuery("from Customer where purchaseValue > 10000 or customerAddress like '%nagar' ").list();
				displayCustomers(customers3);
				System.out.println("-----------AGGREGATE FUNCTIONS-HQL--------------");
				//Aggregate Functions
				Query avgQuery = session.createQuery("select avg(purchaseValue) from Customer");
				Double avgPurchase = (Double)avgQuery.uniqueResult(); // double vs Double
				System.out.println("The Average Purchase Value "+avgPurchase);
				System.out.println("--------------------------");
				Query maxQuery = session.createQuery("select max(purchaseValue) from Customer");
				Integer maxPurchase = (Integer)maxQuery.uniqueResult();
				System.out.println("The Maximum Purchase Value "+maxPurchase);
				
				Query minQuery = session.createQuery("select min(purchaseValue) from Customer");
				Integer minPurchase = (Integer)minQuery.uniqueResult();
				System.out.println("The Minimum Purchase Value "+minPurchase);
				
				System.out.println("-----------AGGREGATE FUNCTIONS-SQL--------------");
				Query avgsqlQuery = session.createSQLQuery("select avg(purchaseValue) from Customer");
				BigDecimal avgsqlPurchase = (BigDecimal)avgsqlQuery.uniqueResult();
				System.out.println("The Average Purchase Value thru SQL "+avgPurchase);
				
				System.out.println("--------------------------");
				Query maxsqlQuery = session.createSQLQuery("select max(purchaseValue) from Customer");
				Integer maxsqlPurchase = (Integer)maxsqlQuery.uniqueResult();
				System.out.println("The Maximum Purchase Value thru sql "+maxsqlPurchase);
				
				System.out.println("--------------HQL------------");
				Query queryCtr = session.createQuery("select count(*) from Customer");
				Long recordCount = (Long)queryCtr.uniqueResult();
				System.out.println("The Record Count is "+recordCount);
				
				System.out.println("------------------------");
				//createQuery(hql) - select * from table1 where column1 = value with single record
				//primary
				System.out.println("-----------Customer with name Kiran-----------");
				Query queryObj = session.createQuery(" from Customer where customerName = 'Kiran' ");
				Object obj =  queryObj.uniqueResult();
				Customer customerObj = (Customer)obj;
				System.out.println("The Customer Retrieved as Object"+customerObj);
				System.out.println("Customer Id "+customerObj.getId()+" CustomerName "+customerObj.getCustomerName());
				
				//createSQLQuery - select a,b,c,d from customer / List <Object[]> data /
				System.out.println("----------using---SQL-----------");
				Query queryArObj = session.createSQLQuery("select custName,custPhone,custAddress,purchaseValue from Customer");
				//List <Customer> customers = queryArObj.list();
				List <Object[]> data = queryArObj.list();
				// for(Customer c:customers)
				for(Object[] row:data)
				{
					System.out.println("CustomerName "+row[0]+"CustomerAddress "+row[1]+"Customer Phone "+row[2]+"Purchase Value"+row[3]);
				}
				System.out.println("------------HQL-----Parameterized queries-------");
				Query queryObj1 = session.createQuery("from Customer where customerAddress like :par1 and purchaseValue > :par2");
				queryObj1.setParameter("par1", "RTNagar");//pstmt.setString(1,value)
				queryObj1.setParameter("par2", 10000);//pstmt.setInt(2,value)
				List <Customer> customersp = queryObj1.list();
				System.out.println(customersp);
				
				System.out.println("-----------Purchase Value-betwn 10000 and 16000-HQL-RANGE----------");
				Query queryObj2 = session.createQuery("from Customer where purchaseValue between :min1 and :max1");
				queryObj2.setParameter("min1", 10000);
				queryObj2.setParameter("max1", 16000);
				List <Customer> customersb = queryObj2.list();
				//System.out.println(customersb);
				displayCustomers(customersb);
				
				System.out.println("-----------Purchase Value-betwn 10000 and 16000 with ?--PARAMETERS using ? ----------");
				Query queryObj3 = session.createQuery("from Customer where purchaseValue between ?0 and ?1 ");
				queryObj3.setParameter(0, 10000);
				queryObj3.setParameter(1, 16000);
				List <Customer> customersbp = queryObj3.list();
				//System.out.println(customersb);
				displayCustomers(customersbp);
				
				
				session.getTransaction().commit();
			
		}
		finally
		{
			sFactory.close();
		}
		
		
	}
	public static void displayCustomers(List <Customer> customers)
	{
		for(Customer c : customers)
		{
			System.out.println(c);
		}
		System.out.println("-------------------------");
	}

}
