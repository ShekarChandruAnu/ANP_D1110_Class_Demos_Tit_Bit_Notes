package com.anu.hib;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class UpdateDealer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		SessionFactory sFactory =	new Configuration()
			.configure("hibernate.cfg.xml")
			.addAnnotatedClass(Dealer.class)
			.buildSessionFactory();
		
		Session session = sFactory.getCurrentSession();
		try
		{
			session.beginTransaction();
		
			
			Dealer dealer =session.get(Dealer.class,1);
			dealer.setDealerAddress("Indiranagar");
			
			session.getTransaction().commit();
			System.out.println("Dealer Updated successfully....");
		}
		finally
		{
			sFactory.close();
		}

	}

}
