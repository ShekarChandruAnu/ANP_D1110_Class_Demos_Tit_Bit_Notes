package com.anu.hib;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class ReadDealer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	SessionFactory sFactory =	new Configuration()
		.configure("hibernate.cfg.xml")
		.addAnnotatedClass(Dealer.class)
		.buildSessionFactory();
	
	Session session = sFactory.getCurrentSession();
	try
	{
		session.beginTransaction();
	
		List <Dealer> dealers = session.createQuery("from Dealer").list();
		for(Dealer d : dealers)
		{
			System.out.println(d);
		}
		System.out.println("-------");
		Dealer dealer =session.get(Dealer.class,1);
		System.out.println(dealer);
		session.getTransaction().commit();
	}
	finally
	{
		sFactory.close();
	}
	}

}
