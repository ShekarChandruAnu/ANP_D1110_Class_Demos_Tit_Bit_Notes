package com.anu.hib;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="dealers")
public class Dealer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="dealerId")
	int dealerId;
	
	@Column(name="dealerName")
	String dealerName;
	
	@Column(name="dealerAddress")
	String dealerAddress;
	
	@Column(name="dealerLimit")
	int dealerLimit;

	
	public Dealer() {
		super();
	}


	public Dealer(String dealerName, String dealerAddress, int dealerLimit) {
		super();
		this.dealerName = dealerName;
		this.dealerAddress = dealerAddress;
		this.dealerLimit = dealerLimit;
	}


	public int getDealerId() {
		return dealerId;
	}


	public void setDealerId(int dealerId) {
		this.dealerId = dealerId;
	}


	public String getDealerName() {
		return dealerName;
	}


	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}


	public String getDealerAddress() {
		return dealerAddress;
	}


	public void setDealerAddress(String dealerAddress) {
		this.dealerAddress = dealerAddress;
	}


	public int getDealerLimit() {
		return dealerLimit;
	}


	public void setDealerLimit(int dealerLimit) {
		this.dealerLimit = dealerLimit;
	}


	@Override
	public String toString() {
		return "Dealer [dealerId=" + dealerId + ", dealerName=" + dealerName + ", dealerAddress=" + dealerAddress
				+ ", dealerLimit=" + dealerLimit + "]";
	}
	
	
	
	

}
