package com.anu.hib;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class InsertDealer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sFactory =	new Configuration()
										.configure("hibernate.cfg.xml")
										.addAnnotatedClass(Dealer.class)
										.buildSessionFactory();
		Session session = sFactory.getCurrentSession();
		try
		{
			session.beginTransaction();
			Dealer dealer1 = new Dealer("Suresh Chawla","Koramangala",120000);
			session.save(dealer1);
			System.out.println("Dealer record inserted Successfully..");
			
			session.getTransaction().commit();
		}
		finally
		{
			sFactory.close();
		}
	}

}
