package com.east.strings;

import java.util.StringTokenizer;

public class StringManipulation {

	// Operators Mathematical/Bit wise/Assignments /Comparison
	// = assignment
	// equals() vs ==
	// equals method checks the values present in the Object
	// == operator checks if both operands(Objects) have same address
	public void manipulateString()
	{
		String str1 = "Hyderabad";
		String str2 = "Hyderabad";
		System.out.println("str1.equals(str2) :"+str1.equals(str2)); // T
		System.out.println("str1 == str2 "+(str1==str2)); //T
		
		String str3 = new String("Bangalore");
		String str4 = new String("Bangalore");
		
		System.out.println("str3.equals(str4) :"+str3.equals(str4)); // T 
		System.out.println("str3 == str4 "+(str3==str4));// False
		
		System.out.println("------------------");
		String str5 = "Bangalore";
		String str6 = "Mangalore";
		System.out.println("str5.equals(str6) :"+str5.equals(str6));  //F
		System.out.println("str5 == str6 "+(str5==str6)); //F
		
		str5 = str6;
		System.out.println("str5.equals(str6) :"+str5.equals(str6));  //T
		System.out.println("str5 == str6 "+(str5==str6)); //T
		System.out.println("------------------");
		String str7 = new String("Bangalore");
		String str8 = new String("Mangalore");
		System.out.println("str7.equals(str8) :"+str7.equals(str8));  //F
		System.out.println("str7 == str8 "+(str7==str8));//F
		
		str7 = str8;
		System.out.println("str7.equals(str8) :"+str7.equals(str8));  //T
		System.out.println("str7 == str8 "+(str7==str8));//T
		
		
	}
	public void manipulateString1()
	{
		String str1 = "World is Beautiful";
	
		System.out.println(" str1.charAt(7)    :"+str1.charAt(7));
		System.out.println(" str1.codePointAt(7)    :"+str1.codePointAt(7));
		
		String str2 = "Hyderabad";
		System.out.println(" str2.charAt(0)    :"+str2.charAt(0));
		System.out.println(" str2.codePointAt(0)    :"+str2.codePointAt(0));
		String str3 = "hyderabad";
		System.out.println(" str3.charAt(0)    :"+str3.charAt(0));
		System.out.println(" str3.codePointAt(0)    :"+str3.codePointAt(0));
		System.out.println("-------COMPARETO method------");
		System.out.println("  str2.compareTo(str3) :"+str2.compareTo(str3));
		System.out.println("  str3.compareTo(str2) :"+str3.compareTo(str2));
		
	/*	String strx = "Hello Old World";
		String stry = "Hello New World";*/
		System.out.println("--------------");
		String strx = "World";
		String stry = "World";
		System.out.println(" strx.compareTo(stry) :"+strx.compareTo(stry));
		System.out.println("  strx.length() "+strx.length());
		String strResult = strx.concat(" is very nice");
		System.out.println(" strx after concatenation :"+strx+ " AFter Concat "+strResult);
		
		
		
	}
	public void manipulateString2()
	{
		StringBuffer sbfr1 = new StringBuffer("world is colourful");
		System.out.println("String Buffer "+sbfr1);
		sbfr1.insert(8, " very");
		System.out.println("String Buffer after mutation "+sbfr1);
		System.out.println("Length of SBFR1 is :"+sbfr1.length());
		
		sbfr1.append(" but also peaceful");
		System.out.println(" sbfr1 after appending :"+sbfr1);
		
		
		StringBuilder sbldr1 = new StringBuilder("world is beautiful");
		System.out.println("String Builder "+sbldr1);
		sbldr1.insert(8, " very");
		System.out.println("String Builder after mutation "+sbldr1);
		System.out.println("Length of SBLDR1 is :"+sbldr1.length());
		
		sbldr1.append(" but also very noisy");
		System.out.println(" sbldr1 after appending :"+sbldr1);
		
		
	}
	public void manipulateString3()
	{
		StringTokenizer strToken = new StringTokenizer("world:is:very:beautiful",":");
		while(strToken.hasMoreElements())
		{
			String myToken = strToken.nextToken();
			System.out.println("Token is "+myToken);
		}
		StringTokenizer strToken1 = new StringTokenizer("world is very beautiful"," ");
		while(strToken1.hasMoreTokens())
		{
			String myToken = strToken1.nextToken();
			System.out.println("Token is "+myToken);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringManipulation	sm = new StringManipulation();
	//	sm.manipulateString();
	//	sm.manipulateString1();
	//	sm.manipulateString2();
		sm.manipulateString3();
	}

}
