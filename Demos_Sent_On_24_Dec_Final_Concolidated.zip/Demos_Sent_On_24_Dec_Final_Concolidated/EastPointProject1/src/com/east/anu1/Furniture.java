package com.east.anu1;

import java.util.Scanner;

public class Furniture {

	protected int length,height,width;
	Scanner scan1; 
	
	public Furniture() {
		super();
		scan1 = new Scanner(System.in);
	}
	// this is an instance of current class
	// super is an instance of parent class
	// super() it invokes the parent class constructor - i.e Object class constructor
	protected void acceptFurnitureDetails()
	{
		System.out.println("Accept the Furniture Details....");
		System.out.println("Enter the Length ");
		length = scan1.nextInt();
		System.out.println("Enter the Height ...");
		height = scan1.nextInt();
		System.out.println("Enter the Width ...");
		width = scan1.nextInt();
	}
	protected void displayFurnitureDetails()
	{
		System.out.println("Displaying the Furniture Details...");
		System.out.println("The Length is "+length);
		System.out.println("The Height is "+height);
		System.out.println("The Width is "+width);
	}
	
	
	
}
